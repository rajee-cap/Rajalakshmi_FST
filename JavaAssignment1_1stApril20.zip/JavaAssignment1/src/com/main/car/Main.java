package com.main.car;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc= new Scanner(System.in);
		int carType = sc.nextInt(); 
		int mileage = sc.nextInt(); 

		switch(carType) {
		case 0: 
			WagonR wagonR= new WagonR(false,"4",String.valueOf(mileage));
			System.out.println("A wagonR is not sedan, is "+wagonR.getSeats()+"-seater car and has "
					+ "mileage of arround "+wagonR.getMileage()+" kmpl");
			break;
			
		case 1:
			HondaCity honda= new HondaCity(true,"4",String.valueOf(mileage));
			System.out.println("A HondaCity is sedan, is "+honda.getSeats()+"-seater car and has "
					+ "mileage of arround "+honda.getMileage()+" kmpl");
			break;
			
		case 2:
			InnovaCrysta innova= new InnovaCrysta(false,"6",String.valueOf(mileage));
			System.out.println("A InnovaCrysta is not sedan, is "+innova.getSeats()+"-seater car and has "
					+ "mileage of arround "+innova.getMileage()+" kmpl");
			break;
			
		default:
			System.out.println("Enter valid input:\n First input must be between 0 and 2. \n And second input must be between 5 and 30.");
			
		}
		

	}

}
