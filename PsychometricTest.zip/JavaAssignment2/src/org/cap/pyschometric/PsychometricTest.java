package org.cap.pyschometric;

import java.util.Scanner;
import java.util.stream.IntStream;

public class PsychometricTest {
	
	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		int noOfElements= sc.nextInt();
		int[] scores=new int[noOfElements];
		for(int i=0; i<noOfElements; i++) {
			scores[i] = sc.nextInt();
		}
		int x= sc.nextInt();
		int[] lowerLimit= new int[x];
		for(int i=0;i<x;i++)
			lowerLimit[i]=sc.nextInt();
		int y= sc.nextInt();
		int[] upperLimit=new int[y];
		for(int i=0;i<y;i++)
			upperLimit[i]=sc.nextInt();
		int candidates[]= new int[upperLimit.length];
		for(int i=0;i<lowerLimit.length;i++) {
			candidates[i]=jobOffers(scores, noOfElements, lowerLimit[i], upperLimit[i]);
		}
		for(int candidate:candidates)
			System.out.println(candidate);
		
		
	}
	
	static int jobOffers(int arr[], int noOfElements, int lowerLimit, int upperLimit) 
    { 
        int count = 0; 
        for (int i = 0; i < noOfElements; i++) { 
      
            if (arr[i] >= lowerLimit && arr[i] <= upperLimit) 
                count++; 
        } 
        return count; 
    } 

}
