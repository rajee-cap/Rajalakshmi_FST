package org.cap.anagram;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class SubString {
	
	public static int start, end;
	
	
	public static void main(String args[]) {
		
		Scanner sc= new Scanner(System.in);
		String word= sc.next();
        System.out.println(shortestSubString(word));
    }
	
	
	private static String shortestSubString(String s) {

        Set<Character> characters = new HashSet<Character>();
        for (int i = 0; i < s.length(); i++) {
            characters.add(s.charAt(i));
        }

        start=0;
        end=s.length()-1;
        Map<Character, Integer> lastIndex = new HashMap<Character, Integer>();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            lastIndex.put(ch, i); 
            if (lastIndex.size() == characters.size()) { 
                int maxDistance = 0;
                for (Map.Entry<Character, Integer> entry : lastIndex.entrySet()) {
                    maxDistance = Math.max(maxDistance, i-entry.getValue());
                }
                if (maxDistance < SubString.getLength()) {
                    start =i- maxDistance;
                    end=i+1;
                }
            }
        }
        return s.substring(start, end);
    }
	
	public static int getLength() {
		return end-start;
	}

}
