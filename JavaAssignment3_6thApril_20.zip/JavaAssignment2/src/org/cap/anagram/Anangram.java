package org.cap.anagram;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Anangram {
	
	
	public static void main(String args[]) 
    { 
		
		Scanner sc= new Scanner(System.in);
		int no_of_words=sc.nextInt();
		String arr[]=null;
		if(no_of_words > 1000) {
			arr = new String[1000];
		} else {
			arr = new String[no_of_words];
		}
		for(int i=0; i<no_of_words; i++) {
			arr[i] = sc.next();
		}
        Anangram anagram=new Anangram();
        ArrayList<String> list=anagram.funWithAnagrams(arr); 
        for(String s:list)
        System.out.println(s);
    } 
	
	
	
	public ArrayList<String> funWithAnagrams(String arr[]) 
    { 
		ArrayList<String> list= new ArrayList<String>();
		
        for (int i = 0; i < arr.length; i++)  {
            	char[] char_arr=arr[i].toCharArray();
            	Arrays.sort(char_arr);
            	list.add(String.valueOf(char_arr));      	
            }
        Collections.sort(list);
        ArrayList<String> newList=new ArrayList<String>();
        for(String word: list) {
        	if (!newList.contains(word)) 
                newList.add(word); 
        }
                
        return newList;
    } 
	
	
}
