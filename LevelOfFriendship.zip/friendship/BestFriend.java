package org.cap.friendship;

public class BestFriend extends Friend {
	
	public String name;
	public String homeTown;
	public String favouriteSong;
	
	public BestFriend(String name, String homeTown,
			String favouriteSong) {
		super(name, homeTown);
		this.name=name;
		this.homeTown = homeTown;
		this.favouriteSong = favouriteSong;
	}
	
	public void getStatus() {
		System.out.println(name +" is my best friend. He is from "+homeTown+" and his favourite song is "+favouriteSong);
	}

}
