package org.cap.friendship;

public class Acquaintance {
	
	public String name;

	public Acquaintance(String name) {
		super();
		this.name = name;
	}
	
	public void getStatus() {
		System.out.println(name +" is just an acquiantance");
	}

}
