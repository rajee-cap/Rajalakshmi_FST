package org.cap.friendship;

public class Friend extends Acquaintance {
	
	public String name;
	public String homeTown;
	
	public Friend(String name, String homeTown) {
		super(name);
		this.name=name;
		this.homeTown = homeTown;
	}
	
	public void getStatus() {
		System.out.println(name +" is a friend and he is from "+homeTown);
	}

}
