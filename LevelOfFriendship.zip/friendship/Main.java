package org.cap.friendship;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		int nos= sc.nextInt();
		ArrayList<String> names= new ArrayList<String>();
		for(int i=0;i<nos;i++) {
			String s = sc.next();
			s += sc.nextLine();
			names.add(s);
		}
		for(String input:names) {
			String detail[]=input.split("\\s+");
		switch(detail[0]) {
		case "Acquaintance":
			Acquaintance ac= new Acquaintance(detail[1]);
			ac.getStatus();
			break;
		case "Friend":
			Friend fr= new Friend(detail[1],detail[2]);
			fr.getStatus();
			break;
		case "BestFriend":
			BestFriend bf= new BestFriend(detail[1],detail[2],detail[3]);
			bf.getStatus();
			break;
		}
		}
	}

}
