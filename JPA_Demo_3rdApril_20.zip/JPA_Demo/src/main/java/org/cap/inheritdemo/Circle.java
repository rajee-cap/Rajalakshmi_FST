package org.cap.inheritdemo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Circle extends Shape {

	public int id;
	public double radius;

	public Circle() {
	}
	
	public Circle(int id) {
		super(id);
	}
	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + "]";
	}

	

}
