package org.cap.inheritdemo;

import javax.persistence.Entity;

@Entity
public class Rectangle extends Shape {
	
	public double length;
	public double width;
	
	

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}
	
	public Rectangle() {
		
	}
	
	public Rectangle(int id) {
		super(id);
	}

	@Override
	public String toString() {
		return "Rectangle [length=" + length + ", width=" + width + "]";
	}
	
	

	
	
	

}
