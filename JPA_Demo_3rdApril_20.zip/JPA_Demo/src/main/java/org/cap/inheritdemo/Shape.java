package org.cap.inheritdemo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Shape {
	
	@Id
	public int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Shape() {
		
	}
	

	public Shape(int id) {
		super();
		this.id = id;
	}

	@Override
	public String toString() {
		return "Shape [id=" + id + "]";
	}
	
	

}
