package org.cap.inheritdemo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.cap.model.Customer;

public class TestMain {
	
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
				entityManagerFactory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Shape shape= new Shape(1);
		
		Circle circle= new Circle();
		circle.setId(2);
		circle.setRadius(10.0);
		
		Rectangle rectangle= new Rectangle();
		rectangle.setId(3);
		rectangle.setLength(10.0);
		rectangle.setWidth(12);
		
		entityManager.persist(shape);
		entityManager.persist(circle);
		entityManager.persist(rectangle);
		
	
		transaction.commit();
		entityManager.close();
		entityManagerFactory.close();
	}

}
