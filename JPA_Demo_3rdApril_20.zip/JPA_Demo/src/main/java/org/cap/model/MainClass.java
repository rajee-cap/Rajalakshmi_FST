package org.cap.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("capg");

		EntityManager entityManager = entityManagerFactory.createEntityManager();

		EntityTransaction transaction = entityManager.getTransaction();

		transaction.begin();

		
		 Customer customer=new Customer(1234,"Jack",LocalDate.now(),34000);
		  
		  Customer tom=new Customer(45435,"TOM",LocalDate.now(),1200,"tom@gmail.com");
		  Customer annie=new
		  Customer(789879,"Annie",LocalDate.now(),1200,"annie@gmail.com");
		  
		  Customer customer1=new Customer(); customer1.setCutomerId(1111);
		  customer1.setCustomerName("Kamal"); customer1.setRegAmount(1200);
		  customer1.setCustPassword("kamal123");
		  
		 entityManager.persist(customer); entityManager.persist(tom);
		 entityManager.persist(annie); entityManager.persist(customer1);
		 


		String sql1 = "select customerName from Customer  where regAmount > 1000 order by customerName";
		Query query = entityManager.createQuery(sql1);
		List<String> ascNames = query.getResultList();
		for(String name:ascNames)
		System.out.println(name);
		
		String sql2 = "select c.customerName from Customer c where c.regAmount > 1000 order by c.customerName desc";
		List<String> descNames = entityManager.createQuery(sql2).getResultList();
		for(String name:descNames)
		System.out.println(name);

		String sql3 = "select sum(c.regAmount) from Customer c where c.regAmount > 1000 group by c.customerName";
		List<Double> amt = entityManager.createQuery(sql3).getResultList();
		System.out.println(amt.get(0));

		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Customer> q = cb.createQuery(Customer.class);
		Root<Customer> c = q.from(Customer.class);
		q.select(c);
		q.where(cb.greaterThan(c.get("regAmount"), "1000"));
		q.groupBy(c.get("customerName"));
		q.orderBy(cb.asc(c.get("customerName")));

		transaction.commit(); 
		entityManager.close();
		entityManagerFactory.close();

	}

}
