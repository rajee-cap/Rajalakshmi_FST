package org.cap.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
@Entity
@Table(name = "cust_table")
public class Customer {
	@Id
	private int cutomerId;
	@Column(length = 100, nullable = false)
	private String customerName;
	
	@Column(name = "registrationDate")
	private LocalDate regDate;
	
	@Column(name = "registrationAmount")
	private double regAmount;
	
	@Column(unique = true)
	private String email;
	
	@Transient
	private String custPassword;
	
	
	
	public String getCustPassword() {
		return custPassword;
	}
	public void setCustPassword(String custPassword) {
		this.custPassword = custPassword;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCutomerId() {
		return cutomerId;
	}
	public void setCutomerId(int cutomerId) {
		this.cutomerId = cutomerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public LocalDate getRegDate() {
		return regDate;
	}
	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}
	public double getRegAmount() {
		return regAmount;
	}
	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}
	public Customer(int cutomerId, String customerName, LocalDate regDate, double regAmount) {
		super();
		this.cutomerId = cutomerId;
		this.customerName = customerName;
		this.regDate = regDate;
		this.regAmount = regAmount;
	}
	
	
	
	public Customer(int cutomerId, String customerName) {
		super();
		this.cutomerId = cutomerId;
		this.customerName = customerName;
	}
	public Customer(int cutomerId, String customerName, LocalDate regDate, double regAmount, String email) {
		super();
		this.cutomerId = cutomerId;
		this.customerName = customerName;
		this.regDate = regDate;
		this.regAmount = regAmount;
		this.email = email;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [cutomerId=" + cutomerId + ", customerName=" + customerName + ", regDate=" + regDate
				+ ", regAmount=" + regAmount + ", email=" + email + ", custPassword=" + custPassword + "]";
	}
	
	
	
}
