package org.cap.boot;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Address;
import org.cap.model.Answer;
import org.cap.model.Company;
import org.cap.model.Employee;
import org.cap.model.Question;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
					emf.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			Address address=new Address("North Avvenue", "Pune");
			Employee employee=new Employee("Tom", 12000, address);
			
			Address address1=new Address("South Avvenue", "Hyderabad");
			Employee employee1=new Employee("Jack", 23000, address1);
			
			Address address2=new Address("South Car Street", "Chennai");
			Employee employee2=new Employee("Annie", 12300, address2);
			
			
			Company company=new Company("Capgemini India Pvt ltd");
			Company company1=new Company("TATA Consultancy");
			employee.setCompany(company);
			employee1.setCompany(company);
			employee2.setCompany(company1);
			
			company.getEmployees().add(employee);
			company.getEmployees().add(employee1);
			
			company1.getEmployees().add(employee);
			company1.getEmployees().add(employee1);
			
			
			entityManager.persist(company1);
			entityManager.persist(company);
			
			entityManager.persist(employee);
			entityManager.persist(employee1);
			entityManager.persist(employee2);
			//entityManager.persist(address);
			
//			entityManager.remove(employee2);
			
			Answer an1=new Answer();  
		    an1.setAnswername("Java is a programming language");  
		    an1.setPostedBy("Ravi Malik");  
		      
		    Answer an2=new Answer();  
		    an2.setAnswername("Java is a platform");  
		    an2.setPostedBy("Sudhir Kumar");  
		     
		    Question q1=new Question();  
		    q1.setQname("What is Java?");  
		    ArrayList<Answer> l1=new ArrayList<Answer>();  
		    l1.add(an1);  
		    l1.add(an2);  
		    q1.setAnswers(l1);  
		    entityManager.persist(q1);
			
		transaction.commit();
		entityManager.detach(employee1);
		entityManager.merge(employee1);
		entityManager.close();
		emf.close();
	}

}
